#include "nco_processing.h"
#ifndef __linux__
int nco_processing_CfgInitialize(nco_processing *InstancePtr, nco_processing_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->nco_processing_BaseAddress = ConfigPtr->nco_processing_BaseAddress;

    InstancePtr->IsReady = 1;
    return XST_SUCCESS;
}
#endif
void nco_processing_step_size_write(nco_processing *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    nco_processing_WriteReg(InstancePtr->nco_processing_BaseAddress, 12, Data);
}
u32 nco_processing_step_size_read(nco_processing *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = nco_processing_ReadReg(InstancePtr->nco_processing_BaseAddress, 12);
    return Data;
}
void nco_processing_right_gain_in_write(nco_processing *InstancePtr, u8 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    nco_processing_WriteReg(InstancePtr->nco_processing_BaseAddress, 4, Data);
}
u8 nco_processing_right_gain_in_read(nco_processing *InstancePtr) {

    u8 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = nco_processing_ReadReg(InstancePtr->nco_processing_BaseAddress, 4);
    return Data;
}
void nco_processing_nco_enable_write(nco_processing *InstancePtr, u32 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    nco_processing_WriteReg(InstancePtr->nco_processing_BaseAddress, 8, Data);
}
u32 nco_processing_nco_enable_read(nco_processing *InstancePtr) {

    u32 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = nco_processing_ReadReg(InstancePtr->nco_processing_BaseAddress, 8);
    return Data;
}
void nco_processing_left_gain_in_write(nco_processing *InstancePtr, u8 Data) {

    Xil_AssertVoid(InstancePtr != NULL);

    nco_processing_WriteReg(InstancePtr->nco_processing_BaseAddress, 0, Data);
}
u8 nco_processing_left_gain_in_read(nco_processing *InstancePtr) {

    u8 Data;
    Xil_AssertVoid(InstancePtr != NULL);

    Data = nco_processing_ReadReg(InstancePtr->nco_processing_BaseAddress, 0);
    return Data;
}
