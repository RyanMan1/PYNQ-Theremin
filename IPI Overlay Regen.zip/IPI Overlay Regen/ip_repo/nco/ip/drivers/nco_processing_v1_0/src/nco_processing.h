#ifndef NCO_PROCESSING__H
#define NCO_PROCESSING__H
#ifdef __cplusplus
extern "C" {
#endif
/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "nco_processing_hw.h"
/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 nco_processing_BaseAddress;
} nco_processing_Config;
#endif
/**
* The nco_processing driver instance data. The user is required to
* allocate a variable of this type for every nco_processing device in the system.
* A pointer to a variable of this type is then passed to the driver
* API functions.
*/
typedef struct {
    u32 nco_processing_BaseAddress;
    u32 IsReady;
} nco_processing;
/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define nco_processing_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define nco_processing_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define nco_processing_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define nco_processing_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif
/************************** Function Prototypes *****************************/
#ifndef __linux__
int nco_processing_Initialize(nco_processing *InstancePtr, u16 DeviceId);
nco_processing_Config* nco_processing_LookupConfig(u16 DeviceId);
int nco_processing_CfgInitialize(nco_processing *InstancePtr, nco_processing_Config *ConfigPtr);
#else
int nco_processing_Initialize(nco_processing *InstancePtr, const char* InstanceName);
int nco_processing_Release(nco_processing *InstancePtr);
#endif
/**
* Write to step_size gateway of nco_processing. Assignments are LSB-justified.
*
* @param	InstancePtr is the step_size instance to operate on.
* @param	Data is value to be written to gateway step_size.
*
* @return	None.
*
* @note    .
*
*/
void nco_processing_step_size_write(nco_processing *InstancePtr, u32 Data);
/**
* Read from step_size gateway of nco_processing. Assignments are LSB-justified.
*
* @param	InstancePtr is the step_size instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 nco_processing_step_size_read(nco_processing *InstancePtr);
/**
* Write to right_gain_in gateway of nco_processing. Assignments are LSB-justified.
*
* @param	InstancePtr is the right_gain_in instance to operate on.
* @param	Data is value to be written to gateway right_gain_in.
*
* @return	None.
*
* @note    .
*
*/
void nco_processing_right_gain_in_write(nco_processing *InstancePtr, u8 Data);
/**
* Read from right_gain_in gateway of nco_processing. Assignments are LSB-justified.
*
* @param	InstancePtr is the right_gain_in instance to operate on.
*
* @return	u8
*
* @note    .
*
*/
u8 nco_processing_right_gain_in_read(nco_processing *InstancePtr);
/**
* Write to nco_enable gateway of nco_processing. Assignments are LSB-justified.
*
* @param	InstancePtr is the nco_enable instance to operate on.
* @param	Data is value to be written to gateway nco_enable.
*
* @return	None.
*
* @note    .
*
*/
void nco_processing_nco_enable_write(nco_processing *InstancePtr, u32 Data);
/**
* Read from nco_enable gateway of nco_processing. Assignments are LSB-justified.
*
* @param	InstancePtr is the nco_enable instance to operate on.
*
* @return	u32
*
* @note    .
*
*/
u32 nco_processing_nco_enable_read(nco_processing *InstancePtr);
/**
* Write to left_gain_in gateway of nco_processing. Assignments are LSB-justified.
*
* @param	InstancePtr is the left_gain_in instance to operate on.
* @param	Data is value to be written to gateway left_gain_in.
*
* @return	None.
*
* @note    .
*
*/
void nco_processing_left_gain_in_write(nco_processing *InstancePtr, u8 Data);
/**
* Read from left_gain_in gateway of nco_processing. Assignments are LSB-justified.
*
* @param	InstancePtr is the left_gain_in instance to operate on.
*
* @return	u8
*
* @note    .
*
*/
u8 nco_processing_left_gain_in_read(nco_processing *InstancePtr);
#ifdef __cplusplus
}
#endif
#endif
