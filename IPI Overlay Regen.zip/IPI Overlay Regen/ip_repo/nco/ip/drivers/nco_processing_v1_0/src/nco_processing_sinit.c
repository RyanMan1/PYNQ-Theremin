/**
* @file nco_processing_sinit.c
*
* The implementation of the nco_processing driver's static initialzation
* functionality.
*
* @note
*
* None
*
*/
#ifndef __linux__
#include "xstatus.h"
#include "xparameters.h"
#include "nco_processing.h"
extern nco_processing_Config nco_processing_ConfigTable[];
/**
* Lookup the device configuration based on the unique device ID.  The table
* ConfigTable contains the configuration info for each device in the system.
*
* @param DeviceId is the device identifier to lookup.
*
* @return
*     - A pointer of data type nco_processing_Config which
*    points to the device configuration if DeviceID is found.
*    - NULL if DeviceID is not found.
*
* @note    None.
*
*/
nco_processing_Config *nco_processing_LookupConfig(u16 DeviceId) {
    nco_processing_Config *ConfigPtr = NULL;
    int Index;
    for (Index = 0; Index < XPAR_NCO_PROCESSING_NUM_INSTANCES; Index++) {
        if (nco_processing_ConfigTable[Index].DeviceId == DeviceId) {
            ConfigPtr = &nco_processing_ConfigTable[Index];
            break;
        }
    }
    return ConfigPtr;
}
int nco_processing_Initialize(nco_processing *InstancePtr, u16 DeviceId) {
    nco_processing_Config *ConfigPtr;
    Xil_AssertNonvoid(InstancePtr != NULL);
    ConfigPtr = nco_processing_LookupConfig(DeviceId);
    if (ConfigPtr == NULL) {
        InstancePtr->IsReady = 0;
        return (XST_DEVICE_NOT_FOUND);
    }
    return nco_processing_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif
