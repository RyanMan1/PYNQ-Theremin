/**
*
* @file nco_processing_hw.h
*
* This header file contains identifiers and driver functions (or
* macros) that can be used to access the device.  The user should refer to the
* hardware device specification for more details of the device operation.
*/ 
#define NCO_PROCESSING_STEP_SIZE 0xc/**< step_size */
#define NCO_PROCESSING_RIGHT_GAIN_IN 0x4/**< right_gain_in */
#define NCO_PROCESSING_NCO_ENABLE 0x8/**< nco_enable */
#define NCO_PROCESSING_LEFT_GAIN_IN 0x0/**< left_gain_in */
